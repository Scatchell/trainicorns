public class RandomizerStub extends Randomizer {
    @Override
    public double random() {
        return 10;
    }
}
