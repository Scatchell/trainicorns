public class Randomizer {
    public double random() {
        return Math.random() * 10;
    }

    public double randomGreaterThanTen() {
        return 0;
    }
}
