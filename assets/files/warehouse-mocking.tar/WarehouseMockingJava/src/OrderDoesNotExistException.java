public class OrderDoesNotExistException extends Throwable {
}
